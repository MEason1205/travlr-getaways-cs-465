import java.io.IOException;
import java.nio.file.*;
import java.time.Instant;
import java.util.List;

public class AppointmentLoader {
    public static void loadAppointmentsFromCSV(String filename, AppointmentService service) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(filename));
        for (int i = 1; i < lines.size(); i++) { // skip header
            String[] parts = lines.get(i).split(",", -1);
            if (parts.length < 3) continue;

            String id = parts[0];
            String desc = parts[1];
            Instant date = Instant.parse(parts[2]);

            Appointment appt = new Appointment(id, desc, date); 
            service.addAppointment(appt);
        }
    }
}
