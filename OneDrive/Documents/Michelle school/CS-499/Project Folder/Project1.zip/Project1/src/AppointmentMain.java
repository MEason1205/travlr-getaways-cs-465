import java.io.IOException;

public class AppointmentMain {
    public static void main(String[] args) {
        AppointmentService service = new AppointmentService();

        try {
            AppointmentLoader.loadAppointmentsFromCSV("appointments.csv", service);
            System.out.println("✅ Appointments loaded successfully!");

            // Print to verify
            for (String id : service.getAppointments().keySet()) {
                Appointment a = service.getAppointment(id);
                System.out.println("ID: " + a.getAppointmentID() +
                                   ", Desc: " + a.getDescription() +
                                   ", Date: " + a.getDate());
            }

        } catch (IOException e) {
            System.err.println("❌ File error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("❌ Data error: " + e.getMessage());
        }
    }
}
